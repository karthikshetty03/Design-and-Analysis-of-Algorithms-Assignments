var searchData=
[
  ['limit_5fval',['LIMIT_VAL',['../_seg_least_8cpp.html#a4538bee1f4b1f77987575edbadf80d2d',1,'SegLeast.cpp']]]
];
