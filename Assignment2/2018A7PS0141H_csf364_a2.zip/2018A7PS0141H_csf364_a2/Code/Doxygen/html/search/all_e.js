var searchData=
[
  ['script_2ecpp',['script.cpp',['../script_8cpp.html',1,'']]],
  ['seg',['seg',['../_seg_least_8cpp.html#a9d71c1ec608dfe96ce8e62f10d97668b',1,'SegLeast.cpp']]],
  ['seg_5fopti',['seg_opti',['../_seg_least_8cpp.html#a1b8992c9e0832429cc3df6f27e9b69e9',1,'SegLeast.cpp']]],
  ['segleast_2ecpp',['SegLeast.cpp',['../_seg_least_8cpp.html',1,'']]],
  ['slope',['slope',['../_seg_least_8cpp.html#a429e2c9c80e74224fc052f2a95ddea7e',1,'SegLeast.cpp']]],
  ['sum_5fx',['sum_x',['../_seg_least_8cpp.html#af33b20889c276d1d199254e02ba3a002',1,'SegLeast.cpp']]],
  ['sum_5fx_5fsqr',['sum_x_sqr',['../_seg_least_8cpp.html#af28d8e5bc6a9549a316147e6fcb30656',1,'SegLeast.cpp']]],
  ['sum_5fxy',['sum_xy',['../_seg_least_8cpp.html#a4f4bad45ca67019a851ca96eaf1ebc4b',1,'SegLeast.cpp']]],
  ['sum_5fy',['sum_y',['../_seg_least_8cpp.html#a4255b8d6aa7acd0e682fbf2cf00035a9',1,'SegLeast.cpp']]],
  ['suminitializer',['sumInitializer',['../_seg_least_8cpp.html#a0b4b1bb4f7756636f938542bcca1df6c',1,'SegLeast.cpp']]]
];
