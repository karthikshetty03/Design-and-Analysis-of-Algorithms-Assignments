var searchData=
[
  ['k',['k',['../_seg_least_8cpp.html#ab66ed8e0098c0a86b458672a55a9cca9',1,'SegLeast.cpp']]]
];
