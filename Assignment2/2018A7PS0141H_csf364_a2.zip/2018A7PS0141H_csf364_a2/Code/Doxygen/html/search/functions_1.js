var searchData=
[
  ['init',['init',['../_seg_least_8cpp.html#a02fd73d861ef2e4aabb38c0c9ff82947',1,'SegLeast.cpp']]],
  ['intercept',['intercept',['../_seg_least_8cpp.html#ac50b55a2b734969544226ce1f5e17437',1,'SegLeast.cpp']]]
];
