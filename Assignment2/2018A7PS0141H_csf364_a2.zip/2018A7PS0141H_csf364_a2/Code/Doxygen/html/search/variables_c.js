var searchData=
[
  ['seg',['seg',['../_seg_least_8cpp.html#a9d71c1ec608dfe96ce8e62f10d97668b',1,'SegLeast.cpp']]],
  ['sum_5fx',['sum_x',['../_seg_least_8cpp.html#af33b20889c276d1d199254e02ba3a002',1,'SegLeast.cpp']]],
  ['sum_5fx_5fsqr',['sum_x_sqr',['../_seg_least_8cpp.html#af28d8e5bc6a9549a316147e6fcb30656',1,'SegLeast.cpp']]],
  ['sum_5fxy',['sum_xy',['../_seg_least_8cpp.html#a4f4bad45ca67019a851ca96eaf1ebc4b',1,'SegLeast.cpp']]],
  ['sum_5fy',['sum_y',['../_seg_least_8cpp.html#a4255b8d6aa7acd0e682fbf2cf00035a9',1,'SegLeast.cpp']]]
];
