var searchData=
[
  ['seg_5fopti',['seg_opti',['../_seg_least_8cpp.html#a1b8992c9e0832429cc3df6f27e9b69e9',1,'SegLeast.cpp']]],
  ['slope',['slope',['../_seg_least_8cpp.html#a429e2c9c80e74224fc052f2a95ddea7e',1,'SegLeast.cpp']]],
  ['suminitializer',['sumInitializer',['../_seg_least_8cpp.html#a0b4b1bb4f7756636f938542bcca1df6c',1,'SegLeast.cpp']]]
];
