var searchData=
[
  ['num',['num',['../_seg_least_8cpp.html#a86cf672daa4e0ad11ad10efc894d19c8',1,'SegLeast.cpp']]],
  ['numr',['numr',['../_seg_least_8cpp.html#aca5dcd2b735960e04518e44b993827e2',1,'SegLeast.cpp']]]
];
