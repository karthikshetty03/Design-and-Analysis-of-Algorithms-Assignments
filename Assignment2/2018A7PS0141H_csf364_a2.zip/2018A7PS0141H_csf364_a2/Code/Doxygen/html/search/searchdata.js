var indexSectionsWithContent =
{
  0: "acdefgijklmnopstvxy",
  1: "p",
  2: "v",
  3: "sv",
  4: "eimosxy",
  5: "acdfgijklmnpstxy",
  6: "il"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Macros"
};

