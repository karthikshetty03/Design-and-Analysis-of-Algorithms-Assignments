var searchData=
[
  ['limit_5fval',['LIMIT_VAL',['../_seg_least_8cpp.html#a4538bee1f4b1f77987575edbadf80d2d',1,'SegLeast.cpp']]],
  ['lines',['lines',['../namespacevisualization.html#a2546f6a744e06c462998b50ca4b7bef3',1,'visualization']]]
];
