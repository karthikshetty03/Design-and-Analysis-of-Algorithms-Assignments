var searchData=
[
  ['mini',['mini',['../_seg_least_8cpp.html#a1aa6417eb5a43771548163f37ee30aa1',1,'SegLeast.cpp']]],
  ['my_5ffile',['my_file',['../namespacevisualization.html#abcab78106d0f62b28c4061665dc194b8',1,'visualization']]]
];
