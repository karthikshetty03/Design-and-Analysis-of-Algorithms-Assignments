var searchData=
[
  ['operator_3c',['operator&lt;',['../struct_point.html#a1ca9f066536167a81c3a14cd87e3f0f7',1,'Point']]],
  ['optimum',['optimum',['../_seg_least_8cpp.html#a38e0da0e5c77472a8518df3830f63c14',1,'SegLeast.cpp']]]
];
