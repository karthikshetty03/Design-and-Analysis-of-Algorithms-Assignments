var searchData=
[
  ['gap',['gap',['../_seg_least_8cpp.html#a29e473eb545feeae50bf3b3c5aafc7dc',1,'SegLeast.cpp']]]
];
